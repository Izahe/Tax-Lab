package lab1tax;
import java.util.Arrays;
import java.util.Scanner;
public class Tax {
	  public static void main(String[] args) {
	    // Create a Scanner object
	    Scanner input = new Scanner(System.in);
	    
	    // Prompt the user to enter martial status
	    System.out.print("Enter the number corresponding to your filing status: \n"
	    		+ "1: Single \n"
	    		+ "2: Head of Household \n"
	    		+ "3: Filing Jointly/Widow \n"
	    		+ "4: Married Filing Seperately \n");
	    int status = input.nextInt();
	    
	    //Prompt the user to enter their earnings
	    System.out.print("Your filing status is: " + status + "\n Enter your earnings: ");
	    
	    double earnings = input.nextInt();
	     double tax = 0.0;
	     
/*Arrays for each filing status 
 - The first number is the maximum number for the tax bracket. 
 - The second number is the maximum number possible with its rate applied to it
*/ 
double[][] Single = {
		{9700, 0.10}, {39475, 0.12}, {84200, 0.22}, {160725, 0.24}, {204100, 0.32}, {510300, 0.35}
		};    
double[][] Head = {
		{13850, 0.10}, {52850, 0.12}, {84200, 0.22}, {160700, 0.24}, {204100, 0.32}, {510300, 0.35}
};
double[][] Joint = {
		{19400, 0.10}, {78950, 0.12}, {168400, 0.22}, {321450, 0.24}, {408200, 0.32}, {612350, 0.35} 
};
double[][] Seperate = {
		{9700, 0.10}, {39475, 0.12}, {84200, 0.22}, {160725, 0.24}, {204100, 0.32}, {306175, 0.35}   
};

// Assigning array for the respective filing status
double[][] array = {};
	    if (status == 1) {
	    	array = Single;
	    }
	    else if (status == 2) {
	    	array = Head;
	    }
	    else if (status == 3) {
	    	array = Joint;
	    }
	    else if (status == 4) {
	    	array = Seperate;
	    }


/* Calculating tax
 */
if (earnings <= array[0][0]) {
	tax = earnings * 0.10;
}
else if (earnings <= array[1][0]) {
	earnings = earnings - array[0][0];
	tax = earnings * 0.12 + (array[0][0] * array[0][1]); //+ 9700 * 0.10
}
else if (earnings <= array[2][0]) {
	earnings = earnings - array[1][0];
	tax = earnings * 0.22 + (array[0][0] * array[0][1]) + (array[1][0] * array[1][1]);
}
else if (earnings <= array[3][0]) {
	earnings = earnings - array[2][0];
	tax = earnings * 0.24 + (array[0][0] * array[0][1]) + (array[1][0] * array[1][1]) + (array[2][0] * array[2][1]);
}
else if (earnings <= array[4][0]) {
	earnings = earnings - array[3][0];
	tax = earnings * 0.32 + (array[0][0] * array[0][1]) + (array[1][0] * array[1][1]) + (array[2][0] * array[2][1]) + (array[3][0] * 
			array[3][1]);
}
else if (earnings <= array[5][0]) {
	earnings = earnings - array [4][0];
	tax = earnings * 0.35 + (array[0][0] * array[0][1]) + (array[1][0] * array[1][1]) + (array[2][0] * array[2][1]) + (array[3][0] * 
			array[3][1]) + (array[4][0] * array [4][1]);
}
else if (earnings <= array[6][0]) {
	earnings = earnings - array[5][0];
	tax = earnings * 0.37 + (array[0][0] * array[0][1]) + (array[1][0] * array[1][1]) + (array[2][0] * array[2][1]) + (array[3][0] * 
			array[3][1]) + (array[4][0] * array [4][1]) + (array[5][0] * array[5][1]);
}

	    System.out.println("Your tax is $" + tax );
	   
	  } 
	}